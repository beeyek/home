from os import system
import re
import csv
try:
    import requests
except:
    system('pip install requests')
from pathlib import Path
try:
    from selenium import webdriver
except:
    system('pip install selenium')
try:
    from fake_useragent import UserAgent
except:
    system('pip install fake-useragent')
from selenium.webdriver.common.by import By
from recaptcha_bypass import solve_recaptcha
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
try:
    from webdriver_manager.chrome import ChromeDriverManager
except:
    system('pip install webdriver-manager')
from selenium.webdriver.support import expected_conditions as EC
try:
    from selenium_authenticated_proxy import SeleniumAuthenticatedProxy
except:
    system('pip install selenium-authenticated-proxy')

# ----------------------------
start_1 = 0
end_1   = 9999999

start_2 = 0
end_2   = 10
# ----------------------------

ua = UserAgent()
usr_agent = ua.firefox
print(usr_agent)

opts = webdriver.ChromeOptions()
opts.add_argument(f"user-agent={usr_agent}")


PROXY_HOST = 'rp.proxyscrape.com'  # rotating proxy or host
PROXY_PORT = 6060 # port
PROXY_USER = 'x5x6d54u9x3pgr7' # username
PROXY_PASS = 'vel5vfhtwpo8yq4' # password

proxy_helper = SeleniumAuthenticatedProxy(
    proxy_url=f"http://{PROXY_USER}:{PROXY_PASS}@{PROXY_HOST}:{PROXY_PORT}")

proxy_helper.enrich_chrome_options(opts)

current_path = Path().absolute()
data_path = current_path.joinpath('data')

driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()),options=opts)

site_url = 'https://lb.agip.gob.ar/ConsultaABL/'
driver.get(site_url)

for num_partida in range(start_1,end_1+1):
    if len(str(num_partida)) < 7:
        num_partida= "0" * (7 - len(str(num_partida))) + str(num_partida)
    for num_fld_Dv in range(start_2,end_2+1):
        while True:
            elm_partida = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
                (By.XPATH, f'//input[@id="fldPartida"]')))
            elm_partida.send_keys(num_partida)

            divDv = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
                (By.XPATH, f'//div[@id="divDv"]')))
            if 'oculto' in divDv.get_attribute('class'):
                print("checkbox is not checked")
                chk_partida_2Dv = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
                    (By.XPATH, f'//input[@id="chkPartida2Dv"]'))) # check-box
                chk_partida_2Dv.click()

            elm_fld_Dv = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
                (By.XPATH, f'//input[@id="fldDv"]')))
            elm_fld_Dv.send_keys(num_fld_Dv)

            solve_recaptcha(driver)

            btn_Consultar = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
                (By.XPATH, f'//button[@id="btnConsultar"]')))
            btn_Consultar.click()

            is_valid = 1
            while True:
                try:
                    error = WebDriverWait(driver, 1).until(EC.presence_of_element_located(
                        (By.XPATH, f'//div[@id="modalAlerta" and contains(@class,"in")]')))
                    is_valid = False
                    break
                except:
                    container_datos = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
                        (By.XPATH, f'//div[@id="containerDatos"]')))
                    if container_datos.text != '':
                        image = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
                            (By.XPATH, f'//div[@id="containerDatos"]//img[contains(@src,"ConsultaABL")]')))
                        is_valid = True
                        break
                try:
                    btn_Consultar.click()
                except:
                    ...

            if is_valid:
                try:
                    match_num = f'{num_partida}-{num_fld_Dv}'

                    business_name_elm = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
                        (By.XPATH, f'//strong[@id="lblRazonSocial"]')))

                    home_elm = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
                        (By.XPATH, f'//strong[@id="lblDomicilio"]')))

                    characteristics_elm = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
                        (By.XPATH, f'//strong[@id="lblCaracteristicas"]')))

                    business_name = business_name_elm.text

                    home = home_elm.text

                    characteristics = characteristics_elm.text

                    cookies = driver.get_cookies()
                    cookie_str = '; '.join([f"{cookie['name']}={cookie['value']}" for cookie in cookies])

                    url = f'https://lb.agip.gob.ar/ConsultaABL/comprobante/ESTADO-DEUDA-ABL-.pdf?boletasSeleccionadas=&identificadorPDF={num_partida}&dvPDF={num_fld_Dv}&fechaInicioPDF='

                    headers = {
                        'Cookie': cookie_str
                    }

                    response = requests.get(url, headers=headers)

                    if response.status_code == 200:
                        with open(data_path.joinpath(f'{num_partida}-{num_fld_Dv}.pdf'), 'wb') as pdf_file:
                            pdf_file.write(response.content)
                        print("PDF file downloaded successfully.")
                    else:
                        print(f"Failed to download the file. Request status: {response.status_code}")

                    with open(data_path.joinpath(f'result.csv'), mode='a', encoding='utf-8', newline='') as product_file:
                        employee_writer = csv.writer(product_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
                        employee_writer.writerow([match_num,business_name,home,characteristics])
                except:
                    match_num = f'{num_partida}-{num_fld_Dv}'
                    with open(data_path.joinpath(f'result.csv'), mode='a', encoding='utf-8', newline='') as product_file:
                        employee_writer = csv.writer(product_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
                        employee_writer.writerow([match_num,'-','-','-'])


                driver.get(site_url)

                driver.refresh()
                break
            else:
                error = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
                    (By.XPATH, f'//div[@id="modalAlerta" and contains(@class,"in")]')))
                if re.search(r'Debe tildar la casilla de verificación', error.text) == None:
                    verificador_is_invalid = True
                else:
                    verificador_is_invalid = False
                btn_close = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
                    (By.XPATH, f'//div[@id="modalAlerta" and contains(@class,"in")]//button[@class="close"]')))
                btn_close.click()
                if verificador_is_invalid:
                    elm_partida = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
                        (By.XPATH, f'//input[@id="fldPartida"]')))
                    for i in range(7):
                        elm_partida.send_keys(Keys.BACK_SPACE)

                    elm_fld_Dv = WebDriverWait(driver, 10).until(EC.presence_of_element_located(
                        (By.XPATH, f'//input[@id="fldDv"]')))
                    for i in range(2):
                        elm_fld_Dv.send_keys(Keys.BACK_SPACE)

                    break
                else:
                    driver.refresh()